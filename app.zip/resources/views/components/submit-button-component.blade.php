<button type="submit" class="btn btn-primary" id="submit-button">
    <i class='fa fa-spinner fa-spin me-2 spinner d-none'></i>
    Submit
</button>
