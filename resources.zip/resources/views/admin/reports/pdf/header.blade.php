<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF Header</title>
    <!-- Add your header styles or any other head content here -->
    <style>
        /* Customize your header styles */
        header {
            text-align: center;
            padding: 10px;
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <!-- Your header content goes here -->
    <header>
        <h1>Your PDF Header</h1>
    </header>
</body>
</html>
