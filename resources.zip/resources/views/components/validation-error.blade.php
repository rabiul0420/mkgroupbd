<div>
    <label {{ $attributes->merge([]) }}  class="error mt-1 text-danger" for="name">{{ $message }}</label>
</div>
