
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <div class="alert-body">
        {{ $message }}
    </div>
</div>
