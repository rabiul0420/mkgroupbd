<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssetNote extends Model
{
    protected $table = "asset_notes";
}
